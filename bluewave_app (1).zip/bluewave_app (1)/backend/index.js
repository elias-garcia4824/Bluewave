import express from "express";
import cors from "cors";
import { Sequelize, DataTypes, Op } from "sequelize"; // ✅ Op importado acá

const app = express();
app.use(cors());
app.use(express.json());

const dbs = {
  Piscinas: new Sequelize("BlueWave", "root", "root", {
    host: "localhost",
    dialect: "mysql",
  }),
  Camaras: new Sequelize("JQ_Seguridad", "root", "root", {
    host: "localhost",
    dialect: "mysql",
  })
};

const defineTrabajoModel = (sequelize) => sequelize.define("Trabajos", {
  tipo: DataTypes.STRING,
  quien: DataTypes.STRING,
  cliente: DataTypes.STRING,
  descripcion: DataTypes.TEXT,
  gastos: DataTypes.DECIMAL(10, 2),
  precio: DataTypes.DECIMAL(10, 2),
  fecha_trabajo: DataTypes.DATEONLY
});

const trabajosModels = {
  Piscinas: defineTrabajoModel(dbs.Piscinas),
  Camaras: defineTrabajoModel(dbs.Camaras)
};

app.get("/api/trabajos/buscar", async (req, res) => {
  const { tipo, quien, cliente, desde, hasta } = req.query;
  const db = dbs[tipo];
  const Trabajo = trabajosModels[tipo];
  if (!db || !Trabajo) return res.status(400).json({ error: "Tipo inválido" });

  const where = {};
  if (quien) where.quien = { [Op.like]: `%${quien}%` };           // ✅ corregido
  if (cliente) where.cliente = { [Op.like]: `%${cliente}%` };     // ✅ corregido
  if (desde && hasta) {
    where.fecha_trabajo = { [Op.between]: [desde, hasta] };       // ✅ corregido
  } else if (desde) {
    where.fecha_trabajo = { [Op.gte]: desde };                    // ✅ corregido
  } else if (hasta) {
    where.fecha_trabajo = { [Op.lte]: hasta };                    // ✅ corregido
  }
app.post("/api/trabajos", async (req, res) => {
  const { tipo, quien, cliente, descripcion, gastos, precio, fecha_trabajo } = req.body;

  if (!tipo || !trabajosModels[tipo]) {
    return res.status(400).json({ error: "Tipo inválido" });
  }

  try {
    const db = dbs[tipo];
    const Trabajo = trabajosModels[tipo];
    await db.authenticate();
    await db.sync();

    const nuevoTrabajo = await Trabajo.create({
      tipo,
      quien,
      cliente,
      descripcion,
      gastos,
      precio,
      fecha_trabajo
    });

    res.status(201).json(nuevoTrabajo);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


  try {
    await db.authenticate();
    await db.sync();
    const trabajos = await Trabajo.findAll({ where, order: [["fecha_trabajo", "DESC"]] });
    res.json(trabajos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(3001, () => {
  console.log("Servidor backend en http://localhost:3001");
});
